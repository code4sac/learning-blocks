from enum import Enum


class ClassType(Enum):
    Homeroom = 'homeroom'
    Scheduled = 'scheduled'
