from enum import Enum


class Importance(Enum):
    Primary = 'primary'
    Secondary = 'secondary'
