from enum import Enum


class TrueFalse(Enum):
    TRUE = 'true'
    FALSE = 'false'
