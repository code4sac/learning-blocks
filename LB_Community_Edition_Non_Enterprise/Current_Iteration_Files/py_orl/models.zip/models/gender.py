from enum import Enum


class Gender(Enum):
    Male = 'male'
    Female = 'female'
