from sqlalchemy import Table, Column, ForeignKey, UUID
from db.base_class import Base

class_academic_session_association = Table(
    'class_academic_session',
    Base.metadata,
    Column('class_id', UUID(), ForeignKey('class.sourcedId')),
    Column('academic_session_id', UUID(), ForeignKey('academic_session.sourcedId'))
)